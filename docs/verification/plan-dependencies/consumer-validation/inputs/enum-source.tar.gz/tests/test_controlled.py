import unittest

class Controlled(unittest.TestCase):
    def test_constant(self):
        self.assertEqual(2 + 2, 4)
