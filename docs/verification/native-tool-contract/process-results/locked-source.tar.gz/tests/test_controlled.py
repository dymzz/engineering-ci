import unittest
class Controlled(unittest.TestCase):
    def test_native(self):
        self.assertTrue(True)
