import unittest

class Generated(unittest.TestCase):
    def test_generated(self):
        print('GENERATED_NATIVE_INPUT_OK')
        self.assertTrue(True)
