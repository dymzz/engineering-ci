## Pytest Results — FAILED

Test execution: **FAILED**; report status: **FAILED**
Original pytest exit code: **1** (tests_failed)
JUnit report available: **true**

| Metric | Count |
| --- | ---: |
| Total | 1 |
| Passed | 0 |
| Failed | 1 |
| Errors | 0 |
| Skipped | 0 |

### Failures

| Test | Category | Message |
| --- | --- | --- |
| tests.test_controlled.Controlled::test_native | assertion_failure | AssertionError: False is not true |

Detailed evidence: download this job's pytest report artifact (`report.json`, optional `junit.xml`).
