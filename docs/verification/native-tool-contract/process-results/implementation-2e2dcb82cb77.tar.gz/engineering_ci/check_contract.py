"""Versioned Check identity and Native Result contract.

This module is the public boundary for #66 consumers. It does not execute
checks, discover tools or grant Required/trusted status. It defines stable
check identities, rule/profile references and result instances so a result can
be associated with the exact Check and source that produced it.

Tool identities (Runtime tool_id/group_id/access_id) are not Check identities.
A missing check_id is refused rather than inferred from a display name. A
declared tool requirement describes which native entries can implement a
Check; a result records the entry that actually ran. A ToolAsset ``tool_id`` is
only recorded when a verified asset identity exists, never derived from an
executable, Hook Job or display name.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, replace
from pathlib import Path
from types import MappingProxyType

from . import weaver_tool

CONTRACT_VERSION = 2
SUPPORTED_RESULT_VERSIONS = frozenset({1, 2})
CHECK_CONTRACT_KIND = "engineering-ci-check-contract"
RESULT_KIND = "engineering-ci-native-check-result"
SATISFACTION_KIND = "engineering-ci-check-satisfaction"
EXECUTION_PHASE = "execution"
POST_COMPLETION_PHASE = "post_completion"
EXECUTION_PHASES = frozenset({EXECUTION_PHASE, POST_COMPLETION_PHASE})
CHECK_ID_PATTERN = re.compile(r"^eci/[a-z0-9][a-z0-9._-]*(/[a-z0-9][a-z0-9._-]*)+$")
STATUSES = frozenset(
    {"passed", "failed", "advisory", "not_applicable", "not_executed", "unknown"}
)
ORIGINS = frozenset({"host", "dagger", "actions", "direct_tool", "unknown"})
# An ECI-local entry is a native invocation this package controls; it is not a
# registered Runtime ToolAccess. A runtime ToolAccess may only be recorded when
# the caller has a verified ToolAsset/ToolAccess registration for it.
TOOL_AUTHORITIES = frozenset({"eci_local_entry", "runtime_tool_access"})
# How a claimed ToolAsset identity is verified. An identity without one of
# these sources is self-reported and refused.
TOOL_ASSET_SOURCES = frozenset({"runtime_tool_asset", "eci_pinned_asset"})
PROCESS_CHECK_IDS = frozenset(
    {
        "eci/hygiene/whitespace",
        "eci/hygiene/docs",
        "eci/hygiene/vulture",
        "eci/hygiene/tach",
        "eci/hygiene/tach-external",
        "eci/tests/unittest",
        "eci/tests/pytest",
        "eci/weaver/registry",
        "eci/weaver/live",
        "eci/weaver/terminal",
        "eci/workflow/actionlint",
        "eci/shell/shellcheck",
        "eci/workflow/shellcheck",
        "eci/workflow/zizmor",
    }
)
INTERNAL_CHECK_IDS = frozenset({"eci/hygiene/forwarding", "eci/sources/reconcile"})


# Built-in identity table for the checks currently produced by this package.
# This is not a runtime registry: consumers cannot register arbitrary names, and
# an unknown name is refused rather than used as an identity.
#
# Adjudication for tests: ``unittest`` and ``pytest`` differ in target
# discovery, exit-code semantics and native artifact support (JUnit XML on
# pytest only), so they stay distinct Check identities rather than alternative
# tools under one logical test Check ID. Cross-engine satisfaction belongs in
# #66/#61 profile policy when explicitly authorized.
CHECK_IDS = MappingProxyType(
    {
        "whitespace": "eci/hygiene/whitespace",
        "forwarding": "eci/hygiene/forwarding",
        "docs": "eci/hygiene/docs",
        "vulture": "eci/hygiene/vulture",
        "tach": "eci/hygiene/tach",
        "tach_external": "eci/hygiene/tach-external",
        "source": "eci/sources/reconcile",
        "unittest": "eci/tests/unittest",
        "pytest": "eci/tests/pytest",
        "weaver_registry": "eci/weaver/registry",
        "weaver_live": "eci/weaver/live",
        "weaver_terminal": "eci/weaver/terminal",
        "actionlint": "eci/workflow/actionlint",
        "shellcheck": "eci/shell/shellcheck",
        "workflow_shellcheck": "eci/workflow/shellcheck",
        "zizmor": "eci/workflow/zizmor",
    }
)


class CheckContractError(ValueError):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class ToolIdentity:
    """One native tool/entry that can implement (part of) a Check.

    Two facts are recorded independently:

    - ``access_id`` + ``authority`` name the invocation entry. An
      ``eci_local_entry`` follows ECI's slash naming; a ``runtime_tool_access``
      is a registered Runtime #27 ToolAccess key in Runtime's own text (for
      example ``trivy.scan``) and does not follow ECI naming.
    - ``tool_id`` + ``tool_id_source`` name the ToolAsset that actually ran and
      how its identity was verified. A verified asset keeps its identity even
      when invoked through an ECI-local entry; an unverified or self-reported
      ``tool_id`` is refused.
    """

    access_id: str
    tool_id: str | None = None
    tool_id_source: str | None = None
    version: str | None = None
    artifact_sha256: str | None = None
    authority: str = "eci_local_entry"


@dataclass(frozen=True)
class ToolRequirement:
    """One required native-tool group; alternatives are allowed implementations.

    Every requirement of a Check must be satisfied. ``after`` records a real
    prerequisite between requirements: the satisfying result must reference the
    prerequisite result it consumed, so the order is evidenced rather than
    presumed. ``when`` optionally names a controlled rule condition governing
    whether the requirement applies.
    """

    requirement_id: str
    alternatives: tuple[ToolIdentity, ...]
    after: tuple[str, ...] = ()
    when: str | None = None


_TOOL_REQUIREMENT_CONDITIONS = frozenset({"registry_baseline_rule"})


@dataclass(frozen=True)
class CheckDefinition:
    check_id: str
    definition_version: int = 1
    tool_id: str | None = None
    access_id: str | None = None
    rule_ref: dict | None = None
    profile_ref: dict | None = None
    requires_baseline: bool = False
    requires_post_completion: bool = False
    tool_requirements: tuple[ToolRequirement, ...] = ()


def _text(value, name):
    if not isinstance(value, str) or not value:
        raise CheckContractError(f"{name}_invalid")
    return value


def _sha256(value, name, *, allow_prefix=False):
    pattern = r"(?:sha256:)?[0-9a-f]{64}" if allow_prefix else r"[0-9a-f]{64}"
    if value is not None and (
        not isinstance(value, str) or not re.fullmatch(pattern, value)
    ):
        raise CheckContractError(f"{name}_invalid")
    return value


_LOCAL_ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
# ECI-controlled native entry names (for example ``git/ls-files``).
_TOOL_ACCESS_PATTERN = re.compile(r"^[a-z0-9][a-z0-9._-]*(/[a-z0-9][a-z0-9._-]*)+$")
# Runtime #27 ToolAccess keys are used as registered: ``trivy.scan`` is legal
# and ECI's slash convention does not apply. Format-only validation does not
# prove registration.
_RUNTIME_ACCESS_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_TOOL_REF_FIELDS = (
    "access_id",
    "tool_id",
    "tool_id_source",
    "version",
    "artifact_sha256",
    "authority",
)


def validate_tool_identity(identity):
    """Validate one declared tool alternative, refusing unverifiable names."""
    if isinstance(identity, dict):
        try:
            identity = ToolIdentity(**identity)
        except TypeError:
            raise CheckContractError("tool_identity_invalid") from None
    if not isinstance(identity, ToolIdentity):
        raise CheckContractError("tool_identity_invalid")
    if identity.authority not in TOOL_AUTHORITIES:
        raise CheckContractError("tool_authority_invalid")
    pattern = (
        _RUNTIME_ACCESS_PATTERN
        if identity.authority == "runtime_tool_access"
        else _TOOL_ACCESS_PATTERN
    )
    if not isinstance(identity.access_id, str) or not pattern.fullmatch(
        identity.access_id
    ):
        raise CheckContractError("tool_access_id_invalid")
    if identity.tool_id is not None and (
        not isinstance(identity.tool_id, str)
        or not _LOCAL_ID_PATTERN.fullmatch(identity.tool_id)
    ):
        raise CheckContractError("tool_id_invalid")
    if identity.authority == "runtime_tool_access":
        if identity.tool_id is None:
            raise CheckContractError("tool_id_required_for_runtime_access")
        if identity.tool_id_source != "runtime_tool_asset":
            raise CheckContractError("tool_asset_source_mismatch")
    if identity.tool_id is None:
        if identity.tool_id_source is not None:
            raise CheckContractError("tool_id_source_without_asset")
    elif identity.tool_id_source not in TOOL_ASSET_SOURCES:
        raise CheckContractError("tool_asset_source_invalid")
    if identity.version is not None:
        _text(identity.version, "tool_version")
    _sha256(identity.artifact_sha256, "tool_artifact_sha256")
    return identity


def tool_ref(
    access_id,
    *,
    tool_id=None,
    tool_id_source=None,
    version=None,
    artifact_sha256=None,
    authority="eci_local_entry",
    executable=None,
):
    """Record the native entry that actually ran; evidence, not a declaration."""
    ref = {
        "access_id": access_id,
        "tool_id": tool_id,
        "tool_id_source": tool_id_source,
        "version": version,
        "artifact_sha256": artifact_sha256,
        "authority": authority,
    }
    if executable is not None:
        ref["executable"] = _text(executable, "tool_executable")
    return validate_tool_ref(ref)


def validate_tool_ref(ref):
    if not isinstance(ref, dict):
        raise CheckContractError("result_tool_invalid")
    if set(ref) - {*_TOOL_REF_FIELDS, "executable"}:
        raise CheckContractError("result_tool_invalid")
    validate_tool_identity({key: ref.get(key) for key in _TOOL_REF_FIELDS})
    if ref.get("executable") is not None:
        _text(ref["executable"], "tool_executable")
    return ref


def _coerce_requirement(value):
    if isinstance(value, ToolRequirement):
        return value
    if isinstance(value, dict):
        try:
            return ToolRequirement(
                requirement_id=value["requirement_id"],
                alternatives=tuple(value["alternatives"]),
                after=tuple(value.get("after") or ()),
                when=value.get("when"),
            )
        except (KeyError, TypeError):
            raise CheckContractError("tool_requirement_invalid") from None
    raise CheckContractError("tool_requirement_invalid")


def _ensure_acyclic(requirements):
    graph = {item.requirement_id: tuple(item.after) for item in requirements}
    state = {}

    def visit(node):
        if state.get(node) == 1:
            raise CheckContractError("tool_requirement_cycle")
        if state.get(node) == 2:
            return
        state[node] = 1
        for prerequisite in graph[node]:
            visit(prerequisite)
        state[node] = 2

    for node in graph:
        visit(node)


def validate_tool_requirements(requirements):
    """Validate the controlled requirement groups of one Check definition."""
    if isinstance(requirements, dict) or not isinstance(requirements, (list, tuple)):
        raise CheckContractError("tool_requirements_invalid")
    items = [_coerce_requirement(item) for item in requirements]
    seen_ids = []
    for item in items:
        if not isinstance(item.requirement_id, str) or not _LOCAL_ID_PATTERN.fullmatch(
            item.requirement_id
        ):
            raise CheckContractError("tool_requirement_id_invalid")
        if item.requirement_id in seen_ids:
            raise CheckContractError("tool_requirement_duplicate")
        seen_ids.append(item.requirement_id)
        if not isinstance(item.alternatives, (list, tuple)) or not item.alternatives:
            raise CheckContractError("tool_alternatives_missing")
        if not isinstance(item.after, (list, tuple)) or any(
            not isinstance(entry, str) for entry in item.after
        ):
            raise CheckContractError("tool_requirement_prerequisite_invalid")
        if item.when is not None and (
            not isinstance(item.when, str)
            or item.when not in _TOOL_REQUIREMENT_CONDITIONS
        ):
            raise CheckContractError("tool_requirement_condition_invalid")
    known = set(seen_ids)
    when_by_id = {item.requirement_id: item.when for item in items}
    for item in items:
        for prerequisite in item.after:
            if prerequisite == item.requirement_id:
                raise CheckContractError("tool_requirement_self_prerequisite")
            if prerequisite not in known:
                raise CheckContractError("tool_requirement_unknown_prerequisite")
            prereq_when = when_by_id[prerequisite]
            if item.when is None and prereq_when is not None:
                raise CheckContractError("tool_requirement_conditional_prerequisite")
            if item.when is not None and prereq_when not in (None, item.when):
                raise CheckContractError("tool_requirement_conditional_prerequisite")
    _ensure_acyclic(items)
    seen_access = set()
    normalized = []
    for item in items:
        alternatives = []
        for alternative in item.alternatives:
            alternative = validate_tool_identity(alternative)
            if alternative.access_id in seen_access:
                raise CheckContractError("tool_alternative_duplicate")
            seen_access.add(alternative.access_id)
            alternatives.append(alternative)
        normalized.append(
            ToolRequirement(
                item.requirement_id,
                tuple(alternatives),
                tuple(item.after),
                item.when,
            )
        )
    return tuple(normalized)


def check_id_for(name):
    """Return the stable Check ID for a built-in display name, or None."""
    return CHECK_IDS.get(name)


def definition_for(name, version=None):
    """Return the current definition, or a historical version when asked."""
    check_id = check_id_for(name)
    if not check_id:
        return None
    if version is None:
        return _CURRENT_BY_ID.get(check_id)
    return _BUILTIN_BY_VERSION.get((check_id, version))


# Exact old→new checks consume the old source as native input. Other checks
# may use changed-path selection, but do not intrinsically inspect old bytes.
#
def _weaver_identity(access_id):
    return ToolIdentity(
        access_id,
        tool_id="weaver",
        tool_id_source="eci_pinned_asset",
        version=weaver_tool.VERSION,
        artifact_sha256=weaver_tool.LINUX_SHA256,
    )


# Native entries are declared here, not inferred at runtime: an alternative's
# ``access_id`` is an ECI-local entry. ``tool_id`` stays empty for host tools
# without an ECI-pinned asset or verified Runtime ToolAsset registration, while
# ``weaver`` binds to ECI's pinned release asset in ``weaver_tool.py``.
_WEAVER_PACKAGING_REQUIREMENTS = (
    ToolRequirement("registry-check", (_weaver_identity("weaver/registry-check"),)),
    ToolRequirement(
        "registry-package",
        (_weaver_identity("weaver/registry-package"),),
        after=("registry-check",),
    ),
    ToolRequirement(
        "registry-local-check",
        (_weaver_identity("weaver/registry-local-check"),),
        after=("registry-package",),
    ),
)

_TOOL_REQUIREMENTS = {
    # ``git ls-files`` determines the checked document set and feeds Lychee.
    "docs": (
        ToolRequirement("inventory", (ToolIdentity("git/ls-files"),)),
        ToolRequirement("links", (ToolIdentity("lychee/docs"),), after=("inventory",)),
    ),
    "tach": (ToolRequirement("module-graph", (ToolIdentity("tach/check"),)),),
    "tach_external": (
        ToolRequirement("external-modules", (ToolIdentity("tach/check-external"),)),
    ),
    "vulture": (ToolRequirement("dead-code", (ToolIdentity("vulture/dead-code"),)),),
    "whitespace": (ToolRequirement("diff-hygiene", (ToolIdentity("git/diff-check"),)),),
    "unittest": (ToolRequirement("test-runner", (ToolIdentity("python/unittest"),)),),
    "pytest": (ToolRequirement("test-runner", (ToolIdentity("python/pytest"),)),),
    "weaver_registry": (
        *_WEAVER_PACKAGING_REQUIREMENTS,
        ToolRequirement(
            "baseline-check",
            (_weaver_identity("weaver/baseline-check"),),
            when="registry_baseline_rule",
        ),
        ToolRequirement(
            "baseline-package",
            (_weaver_identity("weaver/baseline-package"),),
            after=("baseline-check",),
            when="registry_baseline_rule",
        ),
        ToolRequirement(
            "baseline-local-check",
            (_weaver_identity("weaver/baseline-local-check"),),
            after=("baseline-package",),
            when="registry_baseline_rule",
        ),
        ToolRequirement(
            "registry-diff",
            (_weaver_identity("weaver/registry-diff"),),
            after=("registry-local-check", "baseline-local-check"),
            when="registry_baseline_rule",
        ),
    ),
    "weaver_live": (
        *_WEAVER_PACKAGING_REQUIREMENTS,
        ToolRequirement(
            "live-check",
            (_weaver_identity("weaver/live-check"),),
            after=("registry-local-check",),
        ),
    ),
    "weaver_terminal": (
        *_WEAVER_PACKAGING_REQUIREMENTS,
        ToolRequirement(
            "terminal-live-check",
            (_weaver_identity("weaver/terminal-live-check"),),
            after=("registry-local-check",),
        ),
    ),
    "actionlint": (
        ToolRequirement("workflow-lint", (ToolIdentity("actionlint/check"),)),
    ),
    "shellcheck": (ToolRequirement("shell-lint", (ToolIdentity("shellcheck/check"),)),),
    "workflow_shellcheck": (
        ToolRequirement(
            "workflow-inline-shell", (ToolIdentity("actionlint/shellcheck-inline"),)
        ),
    ),
    "zizmor": (ToolRequirement("actions-security", (ToolIdentity("zizmor/check"),)),),
}
# Declaring tool requirements changes when a Check can be satisfied, so it is a
# definition-version change, not only a Result schema change. Version 1 remains
# the pre-tool contract for legacy hygiene checks and stays readable; it can
# never satisfy the upgraded version because the definition versions differ.
# Newly registered check families start tool-bound at version 1.
_LEGACY_PRE_TOOL_V1 = frozenset(
    {"whitespace", "docs", "vulture", "tach", "tach_external"}
)
_CURRENT_DEFINITION_VERSION = {
    "whitespace": 2,
    "forwarding": 1,
    "docs": 2,
    "vulture": 2,
    "tach": 2,
    "tach_external": 2,
    "source": 1,
    "unittest": 1,
    "pytest": 1,
    "weaver_registry": 1,
    "weaver_live": 1,
    "weaver_terminal": 1,
    "actionlint": 1,
    "shellcheck": 1,
    "workflow_shellcheck": 1,
    "zizmor": 1,
}


def _builtin_definitions():
    if PROCESS_CHECK_IDS & INTERNAL_CHECK_IDS:
        raise CheckContractError("check_execution_kind_conflict")
    by_version = {}
    current = {}
    for name, check_id in CHECK_IDS.items():
        if check_id not in PROCESS_CHECK_IDS and check_id not in INTERNAL_CHECK_IDS:
            raise CheckContractError("check_execution_kind_unknown")
        latest = _CURRENT_DEFINITION_VERSION[name]
        for version in range(1, latest + 1):
            requirements = (
                ()
                if name in _LEGACY_PRE_TOOL_V1 and version == 1
                else _TOOL_REQUIREMENTS.get(name, ())
            )
            by_version[(check_id, version)] = CheckDefinition(
                check_id,
                definition_version=version,
                requires_baseline=name in {"whitespace", "forwarding"},
                requires_post_completion=name == "weaver_terminal",
                tool_requirements=requirements,
            )
        current[check_id] = by_version[(check_id, latest)]
    return by_version, current


_versions, _current = _builtin_definitions()
_BUILTIN_BY_VERSION = MappingProxyType(_versions)
_CURRENT_BY_ID = MappingProxyType(_current)


def _registered_definition(check_id, version):
    if check_id not in _CURRENT_BY_ID:
        raise CheckContractError("result_check_unknown")
    definition = _BUILTIN_BY_VERSION.get((check_id, version))
    if definition is None:
        raise CheckContractError("result_check_version_mismatch")
    return definition


def _version(value, name):
    if type(value) is int and value >= 1:
        return str(value)
    return _text(value, name)


def rule_ref(name, version, *, path=None, digest=None, baseline_required=None):
    """A versioned consumer rule reference; not a Required/trust decision."""
    ref = {
        "name": _text(name, "rule_name"),
        "version": _version(version, "rule_version"),
    }
    if path is not None:
        ref["path"] = _text(path, "rule_path")
    if digest is not None:
        ref["sha256"] = _sha256(digest, "rule_sha256", allow_prefix=True)
    if baseline_required is not None:
        if type(baseline_required) is not bool:
            raise CheckContractError("rule_baseline_required_invalid")
        if digest is None:
            raise CheckContractError("rule_ref_unproven")
        ref["baseline_required"] = baseline_required
    return ref


def profile_ref(name, version):
    return {
        "name": _text(name, "profile_name"),
        "version": _version(version, "profile_version"),
    }


def file_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_definition(definition):
    if isinstance(definition, dict):
        definition = CheckDefinition(**definition)
    if not isinstance(definition, CheckDefinition):
        raise CheckContractError("check_definition_invalid")
    if not CHECK_ID_PATTERN.fullmatch(definition.check_id):
        raise CheckContractError("check_id_invalid")
    if (
        type(definition.definition_version) is not int
        or definition.definition_version < 1
    ):
        raise CheckContractError("check_version_invalid")
    if type(definition.requires_baseline) is not bool:
        raise CheckContractError("check_baseline_requirement_invalid")
    if type(definition.requires_post_completion) is not bool:
        raise CheckContractError("check_post_completion_requirement_invalid")
    for value in (definition.tool_id, definition.access_id):
        if value is not None:
            _text(value, "tool_identity")
    # Use the same reference validation as validate_result(), including digest.
    _validate_reference(definition.rule_ref, "rule_ref")
    _validate_reference(definition.profile_ref, "profile_ref")
    registered = _registered_definition(
        definition.check_id, definition.definition_version
    )
    # A definition is accepted only when its Check declares one execution
    # category; otherwise its results could skip native exit/evidence checks.
    _execution_kind(definition.check_id)
    requirements = validate_tool_requirements(definition.tool_requirements)
    if (
        definition.requires_baseline != registered.requires_baseline
        or definition.requires_post_completion != registered.requires_post_completion
    ):
        raise CheckContractError("result_check_semantics_mismatch")
    if requirements != registered.tool_requirements:
        raise CheckContractError("result_tool_requirements_mismatch")
    return replace(
        definition,
        tool_requirements=requirements,
    )


def source_ref(
    snapshot,
    *,
    declared_target_tree=None,
    actual_execution_source=None,
    head_commit=None,
    index_tree=None,
    content_digest=None,
    verified_scope=(),
    binding_status=None,
    scope_kind="changed_paths",
    materialization_ref=None,
):
    """Describe checked source levels without inferring byte binding.

    ``declared_target_tree`` is what the plan intended; it is not proof a tool
    read those bytes. ``byte_tree`` requires an explicit verified scope from a
    materializer; a plain Tree field is never enough.
    """
    result = {"snapshot": _text(snapshot, "snapshot")}
    if declared_target_tree is not None:
        result["declared_target_tree"] = _text(
            declared_target_tree, "declared_target_tree"
        )
    if actual_execution_source is not None:
        result["actual_execution_source"] = _text(
            actual_execution_source, "actual_execution_source"
        )
    for key, value in (
        ("head_commit", head_commit),
        ("index_tree", index_tree),
        ("content_digest", content_digest),
    ):
        if value is not None:
            result[key] = _text(value, key)
    scope = sorted({_text(item, "verified_scope") for item in verified_scope})
    result["verified_input_scope"] = scope
    if scope_kind not in {
        "changed_paths",
        "check_input_closure",
        "full_input_closure",
    }:
        raise CheckContractError("source_scope_kind_invalid")
    result["scope_kind"] = scope_kind
    if materialization_ref is not None:
        result["materialization_ref"] = _text(
            materialization_ref, "materialization_ref"
        )
    if binding_status is None:
        if content_digest is not None and scope:
            binding_status = "content_digest"
        elif declared_target_tree or head_commit or index_tree:
            binding_status = "identity_only"
        else:
            binding_status = "unknown"
    if not isinstance(binding_status, str) or binding_status not in {
        "byte_tree",
        "content_digest",
        "identity_only",
        "unknown",
    }:
        raise CheckContractError("source_binding_invalid")
    if binding_status == "byte_tree" and not (
        declared_target_tree
        and scope
        and scope_kind == "full_input_closure"
        and materialization_ref
    ):
        raise CheckContractError("source_byte_binding_unproven")
    if binding_status == "content_digest" and not (content_digest and scope):
        raise CheckContractError("source_content_binding_unproven")
    result["binding_status"] = binding_status
    return result


def validate_source_ref(source):
    if not isinstance(source, dict):
        raise CheckContractError("source_ref_invalid")
    _text(source.get("snapshot"), "snapshot")
    for key in (
        "declared_target_tree",
        "actual_execution_source",
        "head_commit",
        "index_tree",
        "content_digest",
    ):
        if source.get(key) is not None:
            _text(source[key], key)
    scope = source.get("verified_input_scope")
    if not isinstance(scope, list) or any(
        not isinstance(item, str) or not item for item in scope
    ):
        raise CheckContractError("source_scope_invalid")
    scope_kind = source.get("scope_kind")
    if scope_kind not in {
        "changed_paths",
        "check_input_closure",
        "full_input_closure",
    }:
        raise CheckContractError("source_scope_kind_invalid")
    if source.get("materialization_ref") is not None:
        _text(source["materialization_ref"], "materialization_ref")
    status = source.get("binding_status")
    if status not in {"byte_tree", "content_digest", "identity_only", "unknown"}:
        raise CheckContractError("source_binding_invalid")
    if status == "byte_tree" and not (
        source.get("declared_target_tree")
        and scope
        and scope_kind == "full_input_closure"
        and source.get("materialization_ref")
    ):
        raise CheckContractError("source_byte_binding_unproven")
    if status == "content_digest" and not (source.get("content_digest") and scope):
        raise CheckContractError("source_content_binding_unproven")
    return source


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def _digest(value):
    return "sha256:" + hashlib.sha256(_canonical(value)).hexdigest()


def _validate_reference(ref, name):
    if ref is None:
        return
    if not isinstance(ref, dict):
        raise CheckContractError(f"{name}_invalid")
    _text(ref.get("name"), f"{name}_name")
    _version(ref.get("version"), f"{name}_version")
    if ref.get("sha256") is not None:
        _sha256(ref["sha256"], f"{name}_sha256", allow_prefix=(name == "rule_ref"))
    if "baseline_required" in ref:
        if name != "rule_ref":
            raise CheckContractError(f"{name}_invalid")
        if type(ref["baseline_required"]) is not bool:
            raise CheckContractError("rule_baseline_required_invalid")
        if not ref.get("sha256"):
            raise CheckContractError("rule_ref_unproven")


def _resolve_rule_condition(rule, condition):
    """Resolve a controlled Rule condition: True, False, or None if unresolved."""
    if condition is None:
        return True
    if condition == "registry_baseline_rule":
        if (
            isinstance(rule, dict)
            and rule.get("sha256")
            and "baseline_required" in rule
            and type(rule["baseline_required"]) is bool
        ):
            return rule["baseline_required"]
        return None
    raise CheckContractError("tool_requirement_condition_invalid")


def _unresolved_conditions(definition, *, rule=None):
    return tuple(
        dict.fromkeys(
            item.when
            for item in definition.tool_requirements
            if _resolve_rule_condition(rule, item.when) is None
        )
    )


def _active_requirements(definition, *, rule=None):
    return tuple(
        item
        for item in definition.tool_requirements
        if _resolve_rule_condition(rule, item.when) is True
    )


def _inactive_requirements(definition, *, rule=None):
    return tuple(
        item
        for item in definition.tool_requirements
        if _resolve_rule_condition(rule, item.when) is False
    )


def _unresolved_requirements(definition, *, rule=None):
    return tuple(
        item
        for item in definition.tool_requirements
        if _resolve_rule_condition(rule, item.when) is None
    )


def _execution_kind(check_id):
    """Return the single declared execution category of a controlled Check.

    A registered Check must be declared in exactly one of
    ``PROCESS_CHECK_IDS`` and ``INTERNAL_CHECK_IDS``. Missing or duplicate
    classification is refused instead of returning ``unknown``: the latter
    silently skipped the native exit/evidence requirements in
    ``native_result()`` and ``validate_result()``, so a newly registered Check
    could pass without its native process facts.
    """
    in_process = check_id in PROCESS_CHECK_IDS
    in_internal = check_id in INTERNAL_CHECK_IDS
    if in_process and in_internal:
        raise CheckContractError("check_execution_kind_ambiguous")
    if in_process:
        return "process"
    if in_internal:
        return "internal"
    raise CheckContractError("check_execution_kind_unknown")


def _validate_registered_execution_kinds():
    """Refuse to load a controlled Check that declares no unique category."""
    for check_id in sorted(CHECK_IDS.values()):
        _execution_kind(check_id)


_validate_registered_execution_kinds()


def _validate_baseline(ref):
    if ref is None:
        return
    if not isinstance(ref, dict):
        raise CheckContractError("baseline_ref_invalid")
    present = [
        key
        for key in ("base_commit", "base_ref", "base_tree", "digest")
        if ref.get(key) is not None
    ]
    if not present:
        raise CheckContractError("baseline_ref_invalid")
    for key in present:
        _text(ref[key], key)


def _has_resolved_base_commit(ref):
    if not isinstance(ref, dict):
        return False
    commit = ref.get("base_commit")
    return isinstance(commit, str) and bool(
        re.fullmatch(r"(?:[0-9a-fA-F]{40}|[0-9a-fA-F]{64})", commit)
    )


def _select_declared_tool(definition, tool):
    matched = [
        (requirement, alternative)
        for requirement in definition.tool_requirements
        for alternative in requirement.alternatives
        if alternative.access_id == tool["access_id"]
    ]
    if not matched:
        raise CheckContractError("result_tool_undeclared")
    for requirement, alternative in matched:
        if tool.get("authority") != alternative.authority:
            continue
        # A ToolAsset identity is never invented: it must be declared and equal,
        # including its verification source.
        if tool.get("tool_id") != alternative.tool_id:
            continue
        if tool.get("tool_id_source") != alternative.tool_id_source:
            continue
        # A declared version/artifact is a constraint; an undeclared one may
        # be recorded as observed evidence (for example a pinned Dagger tool).
        if any(
            declared is not None and tool.get(key) != declared
            for key, declared in (
                ("version", alternative.version),
                ("artifact_sha256", alternative.artifact_sha256),
            )
        ):
            continue
        return requirement, alternative
    raise CheckContractError("result_tool_mismatch")


def _validated_result_tool(definition, tool, result_origin):
    """Check observed tool evidence against the controlled declaration.

    A tool-bound Check may omit the observation (the native fact is preserved),
    but then it cannot satisfy the Check. A tool-less Check must not claim one.
    """
    if tool is not None:
        tool = validate_tool_ref(tool)
    if result_origin == "direct_tool" and (
        tool is None
        or tool.get("authority") != "runtime_tool_access"
        or not tool.get("tool_id")
    ):
        raise CheckContractError("direct_tool_identity_missing")
    if not definition.tool_requirements:
        if tool is not None:
            raise CheckContractError("result_tool_unexpected")
        return None
    if tool is None:
        return None
    _select_declared_tool(definition, tool)
    return tool


def native_result(
    definition,
    *,
    source,
    status,
    result_origin,
    result_instance,
    native_exit_code=None,
    input_refs=(),
    artifact_refs=(),
    coverage=None,
    rule_ref=None,
    profile_ref=None,
    evidence=None,
    reason=None,
    runner_ref=None,
    baseline_ref=None,
    tool=None,
    phase=None,
):
    """Create one immutable Native Result.

    ``content_id`` identifies the result content excluding the run instance;
    ``result_id`` additionally binds the run instance. ``tool`` records the
    native entry that actually ran; it is not copied from the definition.
    """
    definition = validate_definition(definition)
    registered = _registered_definition(
        definition.check_id, definition.definition_version
    )
    if status not in STATUSES:
        raise CheckContractError("result_status_invalid")
    if result_origin not in ORIGINS:
        raise CheckContractError("result_origin_invalid")
    if phase is not None and phase not in EXECUTION_PHASES:
        raise CheckContractError("result_phase_invalid")
    _text(result_instance, "result_instance")
    validate_source_ref(source)
    _validate_reference(rule_ref, "rule_ref")
    _validate_reference(profile_ref, "profile_ref")
    if not isinstance(input_refs, (list, tuple)) or any(
        not isinstance(item, dict) for item in input_refs
    ):
        raise CheckContractError("input_refs_invalid")
    if not isinstance(artifact_refs, (list, tuple)) or any(
        not isinstance(item, str) for item in artifact_refs
    ):
        raise CheckContractError("artifact_refs_invalid")
    if evidence is not None and not isinstance(evidence, dict):
        raise CheckContractError("evidence_invalid")
    if native_exit_code is not None and type(native_exit_code) is not int:
        raise CheckContractError("native_exit_code_invalid")
    if status == "passed" and native_exit_code not in (None, 0):
        raise CheckContractError("result_exit_inconsistent")
    if status == "failed" and native_exit_code == 0:
        raise CheckContractError("result_exit_inconsistent")
    # The exit status of a completed process cannot become a skipped Check.
    # A successful probe may establish non-applicability with native evidence.
    if status == "not_executed" and native_exit_code is not None:
        raise CheckContractError("result_nonexecuted_exit_inconsistent")
    if status == "not_applicable" and native_exit_code not in (None, 0):
        raise CheckContractError("result_not_applicable_exit_inconsistent")
    if status == "not_applicable" and native_exit_code == 0 and not evidence:
        raise CheckContractError("result_not_applicable_evidence_missing")
    _validate_baseline(baseline_ref)
    tool = _validated_result_tool(definition, tool, result_origin)
    if (
        registered.requires_baseline
        and status in {"passed", "failed", "advisory"}
        and not _has_resolved_base_commit(baseline_ref)
    ):
        raise CheckContractError("result_baseline_missing")
    if (
        registered.requires_post_completion
        and status in {"passed", "failed", "advisory"}
        and phase != POST_COMPLETION_PHASE
    ):
        raise CheckContractError("result_post_completion_phase_required")
    kind = _execution_kind(definition.check_id)
    if kind == "internal" and native_exit_code is not None:
        raise CheckContractError("result_internal_exit_forbidden")
    if status in {"passed", "failed", "advisory"}:
        if kind == "process":
            if native_exit_code is None:
                raise CheckContractError("result_native_exit_missing")
            if not evidence:
                raise CheckContractError("result_evidence_missing")
        elif kind == "internal" and not evidence:
            raise CheckContractError("result_evidence_missing")
    payload = {
        "kind": RESULT_KIND,
        "schema_version": CONTRACT_VERSION,
        "check": {
            "check_id": definition.check_id,
            "definition_version": definition.definition_version,
            "tool_id": definition.tool_id,
            "access_id": definition.access_id,
            "rule_ref": rule_ref if rule_ref is not None else definition.rule_ref,
            "profile_ref": profile_ref
            if profile_ref is not None
            else definition.profile_ref,
        },
        "source_ref": source,
        "input_refs": list(input_refs),
        "status": status,
        "native_exit_code": native_exit_code,
        "result_origin": result_origin,
        "tool": tool,
        "runner_ref": runner_ref,
        "result_instance": result_instance,
        "artifact_refs": list(artifact_refs),
        "coverage": coverage,
        "evidence": evidence,
        "baseline_ref": baseline_ref,
        "reason": reason,
    }
    if phase is not None:
        payload["phase"] = phase
    content = {key: value for key, value in payload.items() if key != "result_instance"}
    payload["content_id"] = _digest(content)
    payload["result_id"] = _digest(payload)
    # A public constructor must never emit a result its public validator rejects.
    validate_result(payload)
    return payload


def validate_result(result):
    """Recompute identity and reject mutated/inconsistent native results."""
    if not isinstance(result, dict) or result.get("kind") != RESULT_KIND:
        raise CheckContractError("result_invalid")
    schema_version = result.get("schema_version")
    if schema_version not in SUPPORTED_RESULT_VERSIONS:
        raise CheckContractError("result_schema_unsupported")
    check = result.get("check")
    if not isinstance(check, dict):
        raise CheckContractError("result_check_invalid")
    check_id = check.get("check_id")
    if check_id not in set(CHECK_IDS.values()):
        raise CheckContractError("result_check_unknown")
    version = check.get("definition_version")
    if type(version) is not int or version < 1:
        raise CheckContractError("result_check_version_invalid")
    builtin = _registered_definition(check_id, version)
    _validate_reference(check.get("rule_ref"), "rule_ref")
    _validate_reference(check.get("profile_ref"), "profile_ref")
    status = result.get("status")
    if status not in STATUSES:
        raise CheckContractError("result_status_invalid")
    if result.get("result_origin") not in ORIGINS:
        raise CheckContractError("result_origin_invalid")
    _text(result.get("result_instance"), "result_instance")
    validate_source_ref(result.get("source_ref"))
    if not isinstance(result.get("input_refs"), list) or any(
        not isinstance(item, dict) for item in result["input_refs"]
    ):
        raise CheckContractError("input_refs_invalid")
    if not isinstance(result.get("artifact_refs"), list) or any(
        not isinstance(item, str) for item in result["artifact_refs"]
    ):
        raise CheckContractError("artifact_refs_invalid")
    evidence = result.get("evidence")
    if evidence is not None and not isinstance(evidence, dict):
        raise CheckContractError("evidence_invalid")
    exit_code = result.get("native_exit_code")
    if exit_code is not None and type(exit_code) is not int:
        raise CheckContractError("native_exit_code_invalid")
    kind = _execution_kind(check_id)
    if kind == "internal" and exit_code is not None:
        raise CheckContractError("result_internal_exit_forbidden")
    if status == "passed" and exit_code not in (None, 0):
        raise CheckContractError("result_exit_inconsistent")
    if status == "failed" and exit_code == 0:
        raise CheckContractError("result_exit_inconsistent")
    if status == "not_executed" and exit_code is not None:
        raise CheckContractError("result_nonexecuted_exit_inconsistent")
    if status == "not_applicable" and exit_code not in (None, 0):
        raise CheckContractError("result_not_applicable_exit_inconsistent")
    if status == "not_applicable" and exit_code == 0 and not evidence:
        raise CheckContractError("result_not_applicable_evidence_missing")
    _validate_baseline(result.get("baseline_ref"))
    if (
        builtin.requires_baseline
        and status in {"passed", "failed", "advisory"}
        and not _has_resolved_base_commit(result.get("baseline_ref"))
    ):
        raise CheckContractError("result_baseline_missing")
    phase = result.get("phase")
    if phase is not None and phase not in EXECUTION_PHASES:
        raise CheckContractError("result_phase_invalid")
    if (
        builtin.requires_post_completion
        and status in {"passed", "failed", "advisory"}
        and phase != POST_COMPLETION_PHASE
    ):
        raise CheckContractError("result_post_completion_phase_required")
    if status in {"passed", "failed", "advisory"}:
        if kind == "process":
            if exit_code is None:
                raise CheckContractError("result_native_exit_missing")
            if not evidence:
                raise CheckContractError("result_evidence_missing")
        elif kind == "internal" and not evidence:
            raise CheckContractError("result_evidence_missing")
    if (
        result.get("result_origin") == "direct_tool"
        and schema_version == 1
        and (not check.get("tool_id") or not check.get("access_id"))
    ):
        raise CheckContractError("direct_tool_identity_missing")
    if schema_version == 1:
        if "tool" in result:
            raise CheckContractError("result_schema_tool_unsupported")
    else:
        if "tool" not in result:
            raise CheckContractError("result_tool_missing")
        _validated_result_tool(builtin, result.get("tool"), result.get("result_origin"))
    content_id = result.get("content_id")
    result_id = result.get("result_id")
    if not isinstance(content_id, str) or not content_id.startswith("sha256:"):
        raise CheckContractError("content_id_invalid")
    if not isinstance(result_id, str) or not result_id.startswith("sha256:"):
        raise CheckContractError("result_id_invalid")
    payload = {
        key: value
        for key, value in result.items()
        if key not in {"content_id", "result_id"}
    }
    content = {key: value for key, value in payload.items() if key != "result_instance"}
    if _digest(content) != content_id:
        raise CheckContractError("content_id_mismatch")
    expected = dict(payload)
    expected["content_id"] = content_id
    if _digest(expected) != result_id:
        raise CheckContractError("result_id_mismatch")
    return result


def validate_result_set(results):
    """Validate each Result; distinct Ref/rule/profile instances may coexist."""
    if not isinstance(results, (list, tuple)):
        raise CheckContractError("result_set_invalid")
    seen = set()
    for result in results:
        validate_result(result)
        if result["result_id"] in seen:
            raise CheckContractError("result_id_duplicate")
        seen.add(result["result_id"])
    return True


EXPECTED_REQUIRED = ("check_id", "definition_version", "rule_ref", "source_ref")


def validate_expected_instance(expected):
    """Validate one supplied Check expectation, not a consumer-wide set.

    The shape and input claims must be sufficient for a local native match.
    Profile authenticity, complete Expected enumeration, evidence admission
    and Required Gate remain with their actual #66/#63/#61 producers.
    """
    if not isinstance(expected, dict):
        raise CheckContractError("expected_invalid")
    if any(key not in expected for key in EXPECTED_REQUIRED):
        raise CheckContractError("expected_incomplete")
    definition = _registered_definition(
        expected["check_id"], expected["definition_version"]
    )
    rule = expected.get("rule_ref")
    if not isinstance(rule, dict) or not rule.get("sha256"):
        raise CheckContractError("expected_rule_unproven")
    _validate_reference(rule, "rule_ref")
    if "baseline_required" in expected:
        raise CheckContractError("expected_baseline_rule_unproven")
    if _unresolved_conditions(definition, rule=rule):
        raise CheckContractError("expected_baseline_rule_unresolved")
    source = expected.get("source_ref")
    validate_source_ref(source)
    if source["binding_status"] not in {"byte_tree", "content_digest"}:
        raise CheckContractError("expected_source_unproven")
    if (
        source["scope_kind"]
        not in {
            "check_input_closure",
            "full_input_closure",
        }
        or not source["verified_input_scope"]
    ):
        raise CheckContractError("expected_source_scope_insufficient")
    if "input_refs" in expected:
        refs = expected["input_refs"]
        if not isinstance(refs, list) or any(
            not isinstance(item, dict) for item in refs
        ):
            raise CheckContractError("expected_input_refs_invalid")
    if "coverage_by_requirement" in expected:
        mapping = expected["coverage_by_requirement"]
        if not isinstance(mapping, dict) or any(
            not isinstance(key, str) or not isinstance(value, dict)
            for key, value in mapping.items()
        ):
            raise CheckContractError("expected_coverage_mapping_invalid")
        requirement_ids = {
            item.requirement_id for item in _active_requirements(definition, rule=rule)
        }
        if not mapping or set(mapping) - requirement_ids:
            raise CheckContractError("expected_coverage_requirement_unknown")
    if expected.get("profile_ref") is not None:
        _validate_reference(expected["profile_ref"], "profile_ref")
    baseline = expected.get("baseline_ref")
    _validate_baseline(baseline)
    if (
        definition.requires_baseline or expected.get("comparison")
    ) and not _has_resolved_base_commit(baseline):
        raise CheckContractError("expected_baseline_missing")
    phase = expected.get("phase")
    if phase is not None and phase not in EXECUTION_PHASES:
        raise CheckContractError("expected_phase_invalid")
    if definition.requires_post_completion and phase != POST_COMPLETION_PHASE:
        raise CheckContractError("expected_post_completion_phase_required")
    return expected


def result_matches_expected(result, expected):
    """Candidate identity matching only, not Check coverage or Required PASS.

    For a check that natively reads old→new inputs, an assertion lacking the
    actual comparison baseline is too ambiguous even for safe association.
    The #66 Expected/Assessment consumer owns complete scope and satisfaction.
    """
    validate_result(result)
    if not isinstance(expected, dict):
        raise CheckContractError("expected_invalid")
    check = result["check"]
    builtin = _registered_definition(check["check_id"], check["definition_version"])
    if builtin.requires_baseline and expected.get("baseline_ref") is None:
        return False
    if (
        builtin.requires_post_completion
        and expected.get("phase") != POST_COMPLETION_PHASE
    ):
        return False
    if _unresolved_conditions(builtin, rule=expected.get("rule_ref")):
        return False
    comparisons = {
        "check_id": check["check_id"],
        "definition_version": check["definition_version"],
        "rule_ref": check.get("rule_ref"),
        "profile_ref": check.get("profile_ref"),
        "source_ref": result["source_ref"],
        "baseline_ref": result.get("baseline_ref"),
        "phase": result.get("phase"),
    }
    for key, actual in comparisons.items():
        if key in expected and expected[key] != actual:
            return False
    return True


def _expected_decision_base(check_id, definition_version, observed, *, expected_scope):
    return {
        "kind": SATISFACTION_KIND,
        "schema_version": CONTRACT_VERSION,
        "check_id": check_id,
        "definition_version": definition_version,
        "consumer_scope": (
            "supplied_expected_only" if expected_scope else "supplied_results_only"
        ),
        "required": False,
        "trusted": False,
        "result_ids": [item["result_id"] for item in observed],
    }


def _validate_coherent_results(results):
    """Validate result payloads and refuse mixed Check/Source/Rule/Baseline bags.

    All supplied candidates may include failed attempts or multiple runs with the
    same identity facts, but never a heterogeneous bag from different Checks,
    definitions, Rules, Profiles, Sources, or Baselines. #66-C owns routing
    and Run/Attempt qualification before passing a Check's candidate group.
    """
    if not isinstance(results, (list, tuple)):
        raise CheckContractError("satisfaction_results_invalid")
    validate_result_set(results)
    observed = list(results)
    if len(observed) > 1:
        reference = observed[0]
        ref_check = reference["check"]
        for item in observed[1:]:
            check = item["check"]
            if check["check_id"] != ref_check["check_id"]:
                raise CheckContractError("satisfaction_check_mismatch")
            if check["definition_version"] != ref_check["definition_version"]:
                raise CheckContractError("satisfaction_definition_version_mismatch")
            if (
                check.get("rule_ref") != ref_check.get("rule_ref")
                or check.get("profile_ref") != ref_check.get("profile_ref")
                or item.get("source_ref") != reference.get("source_ref")
                or item.get("baseline_ref") != reference.get("baseline_ref")
            ):
                raise CheckContractError("satisfaction_instance_mismatch")
    return observed


def _single_result_expected_failure(result, expected):
    """Pure local Expected check for one Native Result (no ToolRequirement DAG).

    Callers evaluating tool-bound Checks must use evaluate_check_satisfaction()
    so declared Tool Observations and coverage_by_requirement are verified.
    """
    if not result_matches_expected(result, expected):
        return "native_result_mismatched"
    if result["status"] != "passed":
        return "result_not_passed"
    kind = _execution_kind(result["check"]["check_id"])
    if kind == "process" and (
        result["native_exit_code"] != 0 or not result.get("evidence")
    ):
        return "result_not_passed"
    if kind == "internal" and not result.get("evidence"):
        return "result_not_passed"
    if "input_refs" in expected and any(
        ref not in result["input_refs"] for ref in expected["input_refs"]
    ):
        return "expected_inputs_uncovered"
    if "coverage" in expected and expected["coverage"] != result.get("coverage"):
        return "expected_coverage_unproven"
    return None


def result_covers_expected(result, expected):
    """Single supplied Check's native satisfaction, NOT ExpectedSet completeness.

    The result must be valid and match a scoped supplied Expected instance.
    The caller still needs #66 to establish completeness/identity of the whole
    Expected collection and #63/#61 to decide trust and Required policy.
    """
    validate_result(result)
    validate_expected_instance(expected)
    definition = _registered_definition(
        result["check"]["check_id"], result["check"]["definition_version"]
    )
    if not result_matches_expected(result, expected):
        return False
    # Tool-bound Checks (single-requirement and multi-requirement alike) share
    # evaluate_check_satisfaction() so Tool Observations, prerequisite chains,
    # and coverage_by_requirement have one authoritative enforcement path.
    if definition.tool_requirements:
        decision = evaluate_check_satisfaction(definition, [result], expected=expected)
        return decision["status"] == "satisfied"
    return _single_result_expected_failure(result, expected) is None


def results_cover_expected(results, expected):
    """Whether selected successful native witnesses cover one resolved Expected.

    For selected result identities and structured reasons, consumers should
    use evaluate_expected_satisfaction(). Neither API admits trusted evidence.
    """
    return evaluate_expected_satisfaction(results, expected)["status"] == "satisfied"


def _evaluate_toolless_expected(definition, observed, expected):
    """Select one deterministic passing witness for a tool-less Check.

    Ordering by result_id guarantees determinism only; it does not encode
    chronology or authorize cross-Run reuse (#66-C/#63 remain separate).
    """
    decision = _expected_decision_base(
        definition.check_id,
        definition.definition_version,
        observed,
        expected_scope=True,
    )
    if not observed:
        return {
            **decision,
            "status": "unsatisfied",
            "reason": "native_result_missing",
            "requirements": [],
            "selected_result_ids": [],
            "expected_failures": [],
            "expected_failures_complete": True,
            "failure_reasons": ["native_result_missing"],
        }
    expected_failures = []
    failure_reasons = []
    passed_failure = None
    for item in sorted(observed, key=lambda entry: entry["result_id"]):
        failure = _single_result_expected_failure(item, expected)
        if failure is None:
            return {
                **decision,
                "status": "satisfied",
                "reason": "native_pass",
                "requirements": [],
                "selected_result_ids": [item["result_id"]],
                "expected_failures": expected_failures,
                "expected_failures_complete": False,
                "failure_reasons": failure_reasons,
            }
        expected_failures.append(
            {
                "selection": {},
                "result_ids": [item["result_id"]],
                "reason": failure,
            }
        )
        if failure not in failure_reasons:
            failure_reasons.append(failure)
        if item["status"] == "passed" and passed_failure is None:
            passed_failure = failure
    return {
        **decision,
        "status": "unsatisfied",
        "reason": passed_failure or failure_reasons[0],
        "requirements": [],
        "selected_result_ids": [],
        "expected_failures": expected_failures,
        "expected_failures_complete": True,
        "failure_reasons": failure_reasons,
    }


def evaluate_expected_satisfaction(results, expected):
    """Compose native witnesses against one independently bound Expected.

    The selected identities are the SAME results that prove input and
    coverage; #66-C may reference them with the immutable expected_check_ref.
    Deterministic result_id tie-breaking does not establish retry chronology
    or cross-Run trusted reuse; #66-C Routing and #63 Admission remain separate.
    """
    validate_expected_instance(expected)
    observed = _validate_coherent_results(results)
    definition = _registered_definition(
        expected["check_id"], expected["definition_version"]
    )
    if observed and any(
        not result_matches_expected(item, expected) for item in observed
    ):
        return {
            **_expected_decision_base(
                expected["check_id"],
                expected["definition_version"],
                observed,
                expected_scope=True,
            ),
            "status": "unsatisfied",
            "reason": "native_result_mismatched",
            "requirements": [],
            "selected_result_ids": [],
            "expected_failures": [],
            "expected_failures_complete": True,
            "failure_reasons": ["native_result_mismatched"],
        }
    if not definition.tool_requirements:
        return _evaluate_toolless_expected(definition, observed, expected)
    return evaluate_check_satisfaction(definition, observed, expected=expected)


def _expected_witness_failure(requirements, chosen, expected):
    """Why this otherwise successful native witness cannot prove Expected."""
    observed_inputs = [ref for item in chosen.values() for ref in item["input_refs"]]
    if any(ref not in observed_inputs for ref in expected.get("input_refs", [])):
        return "expected_inputs_uncovered"

    # Only terminal native Checks can witness final Check coverage. Inventory
    # may provide data to Lychee, but is not the link scan outcome.
    predecessors = {predecessor for item in requirements for predecessor in item.after}
    terminal_ids = {
        item.requirement_id
        for item in requirements
        if item.requirement_id not in predecessors
    }
    mapping = expected.get("coverage_by_requirement")
    if mapping is not None and any(
        chosen[key].get("coverage") != coverage for key, coverage in mapping.items()
    ):
        return "expected_coverage_unproven"
    if "coverage" in expected and any(
        chosen[key].get("coverage") != expected["coverage"] for key in terminal_ids
    ):
        return "expected_coverage_unproven"
    return None


def _requirement_order(requirements):
    graph = {item.requirement_id: tuple(item.after) for item in requirements}
    ordered = []
    state = {}

    def visit(node):
        if state.get(node) == 2:
            return
        if state.get(node) == 1:
            raise CheckContractError("tool_requirement_cycle")
        state[node] = 1
        for prerequisite in graph[node]:
            visit(prerequisite)
        state[node] = 2
        ordered.append(node)

    for node in graph:
        visit(node)
    by_id = {item.requirement_id: item for item in requirements}
    return [by_id[node] for node in ordered]


def _result_matches_requirement(requirement, result):
    tool = result.get("tool")
    if not isinstance(tool, dict):
        return False
    for alternative in requirement.alternatives:
        if alternative.access_id != tool.get("access_id"):
            continue
        if tool.get("authority") != alternative.authority:
            continue
        if tool.get("tool_id") != alternative.tool_id:
            continue
        if tool.get("tool_id_source") != alternative.tool_id_source:
            continue
        if any(
            declared is not None and tool.get(key) != declared
            for key, declared in (
                ("version", alternative.version),
                ("artifact_sha256", alternative.artifact_sha256),
            )
        ):
            continue
        return True
    return False


def _consumed_result_ids(result):
    refs = result.get("input_refs") or ()
    return {
        ref.get("result_id")
        for ref in refs
        if isinstance(ref, dict) and ref.get("kind") == "check_result"
    }


def evaluate_check_satisfaction(definition, results, *, expected=None):
    """Select native witnesses for every ToolRequirement and its prerequisites.

    Optional expected further constrains that SAME selection by resolved
    input and terminal Check coverage, without weakening valid alternatives.
    For tool-less Checks, expected=None preserves ``not_applicable``, while an
    explicit expected applies the same local single-result validation and
    deterministic candidate selection without cross-Run trust claims.
    """
    definition = validate_definition(definition)
    registered = _registered_definition(
        definition.check_id, definition.definition_version
    )
    if (
        definition.requires_baseline != registered.requires_baseline
        or definition.requires_post_completion != registered.requires_post_completion
    ):
        raise CheckContractError("result_check_semantics_mismatch")
    if definition.tool_requirements != registered.tool_requirements:
        raise CheckContractError("result_tool_requirements_mismatch")
    observed = _validate_coherent_results(results)
    for item in observed:
        check = item["check"]
        if check["check_id"] != definition.check_id:
            raise CheckContractError("satisfaction_check_mismatch")
        if check["definition_version"] != definition.definition_version:
            raise CheckContractError("satisfaction_definition_version_mismatch")
    if expected is not None:
        validate_expected_instance(expected)
        if (
            expected["check_id"] != definition.check_id
            or expected["definition_version"] != definition.definition_version
        ):
            raise CheckContractError("satisfaction_expected_definition_mismatch")
        if observed and any(
            not result_matches_expected(item, expected) for item in observed
        ):
            return {
                **_expected_decision_base(
                    definition.check_id,
                    definition.definition_version,
                    observed,
                    expected_scope=True,
                ),
                "status": "unsatisfied",
                "reason": "native_result_mismatched",
                "requirements": [],
                "selected_result_ids": [],
                "expected_failures": [],
                "expected_failures_complete": True,
                "failure_reasons": ["native_result_mismatched"],
            }

    decision = _expected_decision_base(
        definition.check_id,
        definition.definition_version,
        observed,
        expected_scope=expected is not None,
    )
    if not definition.tool_requirements:
        if expected is not None:
            return _evaluate_toolless_expected(definition, observed, expected)
        return {
            **decision,
            "status": "not_applicable",
            "reason": "no_tool_requirements",
            "requirements": [],
            "selected_result_ids": [],
        }

    active_rule = (
        expected["rule_ref"]
        if expected is not None
        else (observed[0]["check"].get("rule_ref") if observed else definition.rule_ref)
    )
    unresolved_conditions = _unresolved_conditions(definition, rule=active_rule)
    active_requirements = _active_requirements(definition, rule=active_rule)
    inactive_requirements = _inactive_requirements(definition, rule=active_rule)
    unresolved_requirements = _unresolved_requirements(definition, rule=active_rule)
    unexpected_observed = [
        item["result_id"]
        for item in observed
        if any(
            _result_matches_requirement(requirement, item)
            for requirement in inactive_requirements
        )
    ]

    requirements = _requirement_order(active_requirements)
    candidates = {
        requirement.requirement_id: [
            item for item in observed if _result_matches_requirement(requirement, item)
        ]
        for requirement in requirements
    }
    passing = {
        key: sorted(
            (item for item in choices if item["status"] == "passed"),
            key=lambda item: item["result_id"],
        )
        for key, choices in candidates.items()
    }

    chosen = {}
    first_tool_witness = None
    expected_failures = []
    failure_reasons = []

    def visit(position):
        nonlocal first_tool_witness
        if position == len(requirements):
            if first_tool_witness is None:
                first_tool_witness = dict(chosen)
            if expected is None:
                return dict(chosen)
            failure = _expected_witness_failure(requirements, chosen, expected)
            if failure is None:
                return dict(chosen)
            expected_failures.append(
                {
                    "selection": {
                        item.requirement_id: chosen[item.requirement_id]["result_id"]
                        for item in requirements
                    },
                    "result_ids": [
                        chosen[item.requirement_id]["result_id"]
                        for item in requirements
                    ],
                    "reason": failure,
                }
            )
            if failure not in failure_reasons:
                failure_reasons.append(failure)
            return None
        requirement = requirements[position]
        for result in passing[requirement.requirement_id]:
            if any(
                chosen[predecessor]["result_id"] not in _consumed_result_ids(result)
                for predecessor in requirement.after
            ):
                continue
            chosen[requirement.requirement_id] = result
            witness = visit(position + 1)
            if witness is not None:
                return witness
        chosen.pop(requirement.requirement_id, None)
        return None

    selected = visit(0)
    tool_witness = selected if selected is not None else first_tool_witness

    # Preserve precise native failure diagnostics for incomplete job sets.
    # requirements[].satisfied_by reflects native ToolRequirement satisfaction
    # only; when Expected constraints fail, selected_result_ids stays empty.
    partial = {}
    entries = []
    for requirement in requirements:
        key = requirement.requirement_id
        choices = candidates[key]
        entry = {
            "requirement_id": key,
            "after": list(requirement.after),
            "alternatives": [
                alternative.access_id for alternative in requirement.alternatives
            ],
            "observed": [item["result_id"] for item in choices],
            "satisfied_by": None,
            "status": "unsatisfied",
            "reason": "result_missing" if not choices else "result_not_passed",
        }
        picked = tool_witness[key] if tool_witness is not None else None
        if picked is None:
            for candidate in passing[key]:
                blocker = None
                for predecessor in requirement.after:
                    previous = partial[predecessor]
                    if previous["status"] != "satisfied":
                        blocker = "prerequisite_unmet"
                        break
                    if previous["satisfied_by"] not in _consumed_result_ids(candidate):
                        blocker = "prerequisite_unevidenced"
                        break
                if blocker is None:
                    picked = candidate
                    break
                entry["reason"] = blocker
        if picked is not None:
            entry.update(
                status="satisfied",
                reason="native_pass",
                satisfied_by=picked["result_id"],
            )
        partial[key] = entry
        entries.append(entry)

    for requirement in unresolved_requirements:
        observed_ids = [
            item["result_id"]
            for item in observed
            if _result_matches_requirement(requirement, item)
        ]
        entries.append(
            {
                "requirement_id": requirement.requirement_id,
                "after": list(requirement.after),
                "alternatives": [
                    alternative.access_id for alternative in requirement.alternatives
                ],
                "observed": observed_ids,
                "satisfied_by": None,
                "status": "unsatisfied",
                "reason": "rule_condition_unresolved",
            }
        )

    unmet = [item for item in entries if item["status"] != "satisfied"]
    if tool_witness is None and not unmet:
        # Per-requirement local choices do not certify one coherent chain.
        entries[-1].update(
            status="unsatisfied",
            reason="prerequisite_combination_unproven",
            satisfied_by=None,
        )
        unmet = [entries[-1]]
    if unexpected_observed:
        status, reason = "unsatisfied", "unexpected_conditional_requirement"
        selected = None
        if expected is not None and reason not in failure_reasons:
            failure_reasons.append(reason)
    elif unresolved_conditions and observed:
        status, reason = "unsatisfied", "baseline_rule_unresolved"
        selected = None
        if expected is not None and reason not in failure_reasons:
            failure_reasons.append(reason)
    elif selected is not None:
        status, reason = "satisfied", "all_requirements_satisfied"
    elif tool_witness is not None and expected is not None:
        status, reason = "unsatisfied", expected_failures[0]["reason"]
    elif not observed:
        status, reason = "unsatisfied", "native_result_missing"
        if expected is not None and reason not in failure_reasons:
            failure_reasons.append(reason)
    else:
        status, reason = (
            "unsatisfied",
            unmet[0]["reason"] if unmet else "prerequisite_unevidenced",
        )
        if expected is not None and reason not in failure_reasons:
            failure_reasons.append(reason)
    result_payload = {
        **decision,
        "status": status,
        "reason": reason,
        "requirements": entries,
        "selected_result_ids": (
            [selected[item.requirement_id]["result_id"] for item in requirements]
            if selected is not None
            else []
        ),
    }
    if expected is not None:
        result_payload.update(
            expected_failures=expected_failures,
            expected_failures_complete=selected is None,
            failure_reasons=failure_reasons,
        )
    return result_payload


def _definition_payload(definition):
    return {
        "check_id": definition.check_id,
        "definition_version": definition.definition_version,
        "tool_id": definition.tool_id,
        "access_id": definition.access_id,
        "rule_ref": definition.rule_ref,
        "profile_ref": definition.profile_ref,
        "requires_baseline": definition.requires_baseline,
        "requires_post_completion": definition.requires_post_completion,
        "tool_requirements": [
            {
                "requirement_id": item.requirement_id,
                "alternatives": [
                    {
                        "access_id": alternative.access_id,
                        "tool_id": alternative.tool_id,
                        "tool_id_source": alternative.tool_id_source,
                        "version": alternative.version,
                        "artifact_sha256": alternative.artifact_sha256,
                        "authority": alternative.authority,
                    }
                    for alternative in item.alternatives
                ],
                "after": list(item.after),
                **({"when": item.when} if item.when is not None else {}),
            }
            for item in definition.tool_requirements
        ],
    }


def resolve_definitions(required=None):
    """Resolve an explicit request list; never claim a consumer-wide set."""
    if required is None:
        return {
            "kind": "engineering-ci-check-definition-set",
            "schema_version": CONTRACT_VERSION,
            "source": "check_contract.builtin.v1",
            "scope": "requested_names",
            "consumer_completeness": "not_claimed",
            "status": "unknown",
            "reason": "required_scope_missing",
            "definitions": [],
            "missing": [],
            "conflicts": [],
        }
    required = list(required)
    definitions = []
    missing = []
    seen = set()
    for item in required:
        definition = None
        if item in CHECK_IDS:
            definition = definition_for(item)
        else:
            definition = _CURRENT_BY_ID.get(item)
        if definition is None:
            missing.append(str(item))
            continue
        if definition.check_id not in seen:
            definitions.append(_definition_payload(definition))
            seen.add(definition.check_id)
    if not required:
        status, reason = "unknown", "empty_request_not_proof"
    elif missing and definitions:
        status, reason = "partial", "required_definitions_missing"
    elif missing:
        status, reason = "unknown", "required_definitions_missing"
    else:
        status, reason = "complete", "requested_names_complete"
    return {
        "kind": "engineering-ci-check-definition-set",
        "schema_version": CONTRACT_VERSION,
        "source": "check_contract.builtin.v1",
        "scope": "requested_names",
        "consumer_completeness": "not_claimed",
        "status": status,
        "reason": reason,
        "definitions": definitions,
        "missing": missing,
        "conflicts": [],
    }
