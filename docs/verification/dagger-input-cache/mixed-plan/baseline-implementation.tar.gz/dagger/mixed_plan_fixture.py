"""Count actual mixed-Plan work; observers call the original implementations."""

import json
import time
from pathlib import Path

from . import link_cache_fixture


async def observe(module, plan, source):
    from engineering_ci import execution, native_producer, plan_contract, selection

    commands = []
    checks = []
    original_command = execution._run_command
    original_check = execution.run_host_check

    def command(*args, **kwargs):
        started = time.time_ns()
        completed, argv = original_command(*args, **kwargs)
        commands.append(
            {
                "argv": argv,
                "started_at_unix_ns": started,
                "finished_at_unix_ns": time.time_ns(),
                "exit_code": completed.returncode,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
            }
        )
        return completed, argv

    def check(*args, **kwargs):
        started = time.time_ns()
        result = original_check(*args, **kwargs)
        checks.append(
            {
                "name": result.get("name"),
                "started_at_unix_ns": started,
                "finished_at_unix_ns": time.time_ns(),
                "status": result.get("status"),
                "exit_code": result.get("exit_code"),
                "result_id": result.get("result_id"),
            }
        )
        return result

    async def audit():
        return {
            "module_local_processes": list(commands),
            "local_check_calls": list(checks),
        }

    execution._run_command = command
    execution.run_host_check = check
    try:
        bundle = await link_cache_fixture.observe(module, plan, source, audit=audit)
    finally:
        execution._run_command = original_command
        execution.run_host_check = original_check
    observations = await audit()
    implementation, hashes = native_producer.implementation(
        "engineering-ci/dagger/mixed-plan-observation",
        {
            "dagger/mixed_plan_fixture.py": Path(__file__),
            "engineering_ci/selection.py": Path(selection.__file__),
            "engineering_ci/plan_contract.py": Path(plan_contract.__file__),
        },
    )
    observations.update(implementation=implementation, implementation_sources=hashes)
    return bundle.with_new_file(
        "mixed-observations.json", json.dumps(observations, sort_keys=True)
    )
