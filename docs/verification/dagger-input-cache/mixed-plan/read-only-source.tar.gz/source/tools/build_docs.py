from pathlib import Path
Path('inputs/payload.txt').write_text('forbidden source write')
import hashlib
import json
import os
import time
from pathlib import Path

started = time.time_ns()
payload = Path("inputs/payload.txt").read_bytes()
digest = hashlib.pbkdf2_hmac("sha256", payload, b"eci-docs", 4_000_000).hex()
out = Path(os.environ["ENGINEERING_CI_ARTIFACT_DIR"]) / "docs/generated.md"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text("# Generated\n\n" + digest + "\n\n[local](local.md)\n", encoding="utf-8")
print(json.dumps({"started_at_unix_ns": started, "finished_at_unix_ns": time.time_ns(), "output_sha256": hashlib.sha256(out.read_bytes()).hexdigest()}))
