# Links

[remote](http://link-fixture:8080/target)

[local](local.md)
