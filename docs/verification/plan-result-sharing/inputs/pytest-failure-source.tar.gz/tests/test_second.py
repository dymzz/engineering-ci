import unittest


class Second(unittest.TestCase):
    def test_second(self):
        self.assertEqual(3 + 3, 7)
