import unittest
import uuid


class Controlled(unittest.TestCase):
    def test_controlled(self):
        print("native-witness=" + str(uuid.uuid4()))
        self.assertEqual(2 + 2, 4)
