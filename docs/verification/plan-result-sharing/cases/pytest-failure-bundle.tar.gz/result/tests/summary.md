## Pytest Results — FAILED

Test execution: **FAILED**; report status: **FAILED**
Original pytest exit code: **1** (tests_failed)
JUnit report available: **true**

| Metric | Count |
| --- | ---: |
| Total | 2 |
| Passed | 1 |
| Failed | 1 |
| Errors | 0 |
| Skipped | 0 |

### Failures

| Test | Category | Message |
| --- | --- | --- |
| tests.test_second.Second::test_second | assertion_failure | AssertionError: 6 != 7 |

Detailed evidence: download this job's pytest report artifact (`report.json`, optional `junit.xml`).
